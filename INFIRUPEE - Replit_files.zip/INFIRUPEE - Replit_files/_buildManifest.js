self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/da94a9ad91c136b3.js"
  ],
  "/_error": [
    "static/chunks/cfc6ff469e70017a.js"
  ],
  "/account": [
    "static/chunks/6d61c85db3c510ef.js"
  ],
  "/account/additional-billing-settings": [
    "static/chunks/9c6af9ea96e219e4.js"
  ],
  "/actionCode": [
    "static/chunks/372925a686a1f769.js"
  ],
  "/agentInboxAuth": [
    "static/chunks/0d2382ed052fce69.js"
  ],
  "/agentVerify": [
    "static/chunks/c6680b7cecae90fa.js"
  ],
  "/agentVerify2": [
    "static/chunks/07754d353668da3a.js"
  ],
  "/appTest": [
    "static/chunks/349a1f19947bc562.js"
  ],
  "/auth": [
    "static/chunks/3ce917ae0a9e583d.js"
  ],
  "/authComplete": [
    "static/chunks/9e8aa0ff568917b6.js"
  ],
  "/authWithReplco": [
    "static/chunks/09d53f33a728ee2e.js"
  ],
  "/authWithReplcoCloser": [
    "static/chunks/bbb514b56f574874.js"
  ],
  "/blank": [
    "static/chunks/9fda4f7b626073fe.js"
  ],
  "/brandkit": [
    "static/chunks/fb6b52c1c4b36328.js"
  ],
  "/cashOut": [
    "static/chunks/b3f8d412f6a31623.js"
  ],
  "/checkout": [
    "static/chunks/2c8f77960b3152b9.js"
  ],
  "/cli": [
    "static/chunks/4eeb6ccd183060ce.js"
  ],
  "/communityHub": [
    "static/chunks/9656e753561c635c.js"
  ],
  "/cycles": [
    "static/chunks/d16e372cb6de9f04.js"
  ],
  "/deeplink-handler": [
    "static/chunks/b42618c2d0f0e346.js"
  ],
  "/deployment-login": [
    "static/chunks/b2a751d1efc19863.js"
  ],
  "/desktop": [
    "static/chunks/3052cfaaa03cf64f.js"
  ],
  "/desktopApp/auth": [
    "static/chunks/ba089c9a3ab2711e.js"
  ],
  "/desktopApp/authSuccess": [
    "static/chunks/3e695655fdbc39c1.js"
  ],
  "/desktopApp/home": [
    "static/chunks/be7e311affbe0815.js"
  ],
  "/desktopApp/open": [
    "static/chunks/a7554c5636389bad.js"
  ],
  "/dev/confetti": [
    "static/chunks/9be1087efd09d830.js"
  ],
  "/developer-frameworks": [
    "static/chunks/07854dc82aeb2ad8.js"
  ],
  "/developerDay": [
    "static/chunks/abe345b35e86eef6.js"
  ],
  "/evaluations": [
    "static/chunks/857cea1beb3af4d6.js"
  ],
  "/expiredPrivateRepl": [
    "static/chunks/fe52d7b6f5981f0e.js"
  ],
  "/extensions": [
    "static/chunks/e43538f0313237ff.js"
  ],
  "/extensions/extension": [
    "static/chunks/fa311d6e4af58493.js"
  ],
  "/externalClaim": [
    "static/chunks/c3631cb0617cb98c.js"
  ],
  "/forgot": [
    "static/chunks/f96a224f1764b7af.js"
  ],
  "/glitch": [
    "static/chunks/f837a06f7329b78b.js"
  ],
  "/googlenext": [
    "static/chunks/e1adb76494768fb6.js"
  ],
  "/grab": [
    "static/chunks/2b9f3c6c998492a3.js"
  ],
  "/help": [
    "static/chunks/d0ae69b7fd8b7b0a.js"
  ],
  "/home": [
    "static/chunks/3be5f02dcbfe4613.js"
  ],
  "/hostingDeployments": [
    "static/chunks/c76751440858c85b.js"
  ],
  "/hostingDeployments/hostingDeployment": [
    "static/chunks/c1be0109f561269f.js"
  ],
  "/import": [
    "static/chunks/fda9129bd8eebb3f.js"
  ],
  "/import/[provider]": [
    "static/chunks/f16aba8ef76088e8.js"
  ],
  "/instantGitHubContentsImport": [
    "static/chunks/1f9a07db4350d366.js"
  ],
  "/integrations": [
    "static/chunks/e7cd03f6d9d59ebb.js"
  ],
  "/integrations/[connectorName]": [
    "static/chunks/aac9cdd88d63be85.js"
  ],
  "/integrations/[connectorName]/apps/[appId]": [
    "static/chunks/e8c846a47f72fb73.js"
  ],
  "/language": [
    "static/chunks/581511a234236ba2.js"
  ],
  "/mark": [
    "static/chunks/a20c60a538f2c36a.js"
  ],
  "/mobile": [
    "static/chunks/5c73b48593bc257e.js"
  ],
  "/mobileApp/home": [
    "static/chunks/5230c75c51b25ab4.js"
  ],
  "/mobileApp/startWithAI": [
    "static/chunks/c0e5f066522dd34c.js"
  ],
  "/mobileDownload": [
    "static/chunks/5f9571efb061d81f.js"
  ],
  "/mock-home": [
    "static/chunks/2befe38dd506ff7c.js"
  ],
  "/native-saml-sign-in": [
    "static/chunks/483ca5ccb25a5fe1.js"
  ],
  "/newExtension": [
    "static/chunks/a095231241e6ab5e.js"
  ],
  "/notifications": [
    "static/chunks/173a0bae867a5153.js"
  ],
  "/pricing": [
    "static/chunks/3c03c33f63cd5a25.js"
  ],
  "/profile": [
    "static/chunks/18dde830f819c721.js"
  ],
  "/replEmbed": [
    "static/chunks/b1c0f4306f151fa8.js"
  ],
  "/replEnvironmentDesktop": [
    "static/chunks/2fda52e25886c283.js"
  ],
  "/replEnvironmentMobile": [
    "static/chunks/d68ca1aff38031dd.js"
  ],
  "/replView": [
    "static/chunks/1e66946a890196ad.js"
  ],
  "/replitAuth": [
    "static/chunks/23f0a4b2c704ac7b.js"
  ],
  "/replitAuthConsent": [
    "static/chunks/e1153b231c58b231.js"
  ],
  "/replitAuthError": [
    "static/chunks/10842c8e47dab1d6.js"
  ],
  "/replsDashboard": [
    "static/chunks/b1f4d0b90348c7c7.js"
  ],
  "/rewind2025": [
    "static/chunks/5aa9b07af2989f24.js"
  ],
  "/routeTest": [
    "static/chunks/5af9d308fafc6c7f.js"
  ],
  "/search": [
    "static/chunks/7ead2812d0458abe.js"
  ],
  "/site/githubClassroomNotice": [
    "static/chunks/f917f7a19db15484.js"
  ],
  "/stripe-checkout-error": [
    "static/chunks/2beb49881a06670f.js"
  ],
  "/stripe-checkout-success": [
    "static/chunks/a0ae37f46680867a.js"
  ],
  "/t/[orgSlug]": [
    "static/chunks/6e6a9a88c2dee306.js"
  ],
  "/t/[orgSlug]/accept-invite/[inviteCode]": [
    "static/chunks/0973a4d7927f7e38.js"
  ],
  "/t/[orgSlug]/accept-sponsored-subscription/[inviteCode]": [
    "static/chunks/0f44a200dce7c049.js"
  ],
  "/t/[orgSlug]/analytics": [
    "static/chunks/158b445b9b6866c2.js"
  ],
  "/t/[orgSlug]/deployments": [
    "static/chunks/00b1ab48eccf138d.js"
  ],
  "/t/[orgSlug]/developer-frameworks": [
    "static/chunks/bde7fe541c65c237.js"
  ],
  "/t/[orgSlug]/groups": [
    "static/chunks/fa83ff7c1d7d169e.js"
  ],
  "/t/[orgSlug]/groups/[groupSlug]/[groupId]/members": [
    "static/chunks/d9b75b50b32fa998.js"
  ],
  "/t/[orgSlug]/groups/[groupSlug]/[groupId]/permissions": [
    "static/chunks/f9176f3905a59e53.js"
  ],
  "/t/[orgSlug]/groups/[groupSlug]/[groupId]/settings": [
    "static/chunks/79c45fbd20241bef.js"
  ],
  "/t/[orgSlug]/integrations": [
    "static/chunks/43696ca73e1da473.js"
  ],
  "/t/[orgSlug]/integrations/[connectorName]": [
    "static/chunks/c00c2fed450e58b1.js"
  ],
  "/t/[orgSlug]/integrations/[connectorName]/apps/[appId]": [
    "static/chunks/a61de8ec02949694.js"
  ],
  "/t/[orgSlug]/members": [
    "static/chunks/bbb5824c0d87d30e.js"
  ],
  "/t/[orgSlug]/profile": [
    "static/chunks/89c664e113ef298a.js"
  ],
  "/t/[orgSlug]/profile/settings": [
    "static/chunks/c5e237991b004dcd.js"
  ],
  "/t/[orgSlug]/projects": [
    "static/chunks/67904e20aa9d4311.js"
  ],
  "/t/[orgSlug]/projects/[projectId]": [
    "static/chunks/46d1307df5891360.js"
  ],
  "/t/[orgSlug]/repls": [
    "static/chunks/6ffc6b2183c70876.js"
  ],
  "/t/[orgSlug]/security": [
    "static/chunks/8c7612f878eeb66f.js"
  ],
  "/t/[orgSlug]/settings/[[...tab]]": [
    "static/chunks/5a2b7662b7c466af.js"
  ],
  "/t/[orgSlug]/theme-editor": [
    "static/chunks/875c00cb6f9a9725.js"
  ],
  "/t/[orgSlug]/usage": [
    "static/chunks/5474adea4e95405e.js"
  ],
  "/t/join": [
    "static/chunks/e36c9ea6833245c4.js"
  ],
  "/t/new": [
    "static/chunks/57dcb3c50a1ef62d.js"
  ],
  "/teamError": [
    "static/chunks/bc41b6d6acf14f9d.js"
  ],
  "/teams/join": [
    "static/chunks/5497a758e2f7b2cf.js"
  ],
  "/teams/new": [
    "static/chunks/d2d4b23174e81118.js"
  ],
  "/templates/templates": [
    "static/chunks/ca82bd957bae49c9.js"
  ],
  "/templates/templatesCategory": [
    "static/chunks/245d7e63bc8575f1.js"
  ],
  "/theme-editor": [
    "static/chunks/f2a40a44db7dada9.js"
  ],
  "/themes": [
    "static/chunks/ba58df018d6185cf.js"
  ],
  "/themes/create": [
    "static/chunks/639828926a99ca28.js"
  ],
  "/themes/edit": [
    "static/chunks/f70dcd46bcd2d103.js"
  ],
  "/themes/theme": [
    "static/chunks/45c7b9f73403fef1.js"
  ],
  "/unauthorized-deployment": [
    "static/chunks/9766e1725e9aa579.js"
  ],
  "/unauthorized-devdomain": [
    "static/chunks/2ab8a4e34c8d3c56.js"
  ],
  "/usage": [
    "static/chunks/0789246432c72d8a.js"
  ],
  "/userDataExport": [
    "static/chunks/75017abf389d4edf.js"
  ],
  "/verify": [
    "static/chunks/a78a648f97929c56.js"
  ],
  "/verifyEmail": [
    "static/chunks/3c3dc679deec5f4e.js"
  ],
  "/watchNixMigration": [
    "static/chunks/cd2f1e3f4b13aad4.js"
  ],
  "/welcome": [
    "static/chunks/28e256f1d0fb9d56.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/account",
    "/account/additional-billing-settings",
    "/actionCode",
    "/agentInboxAuth",
    "/agentVerify",
    "/agentVerify2",
    "/appTest",
    "/auth",
    "/authComplete",
    "/authWithReplco",
    "/authWithReplcoCloser",
    "/blank",
    "/brandkit",
    "/cashOut",
    "/checkout",
    "/cli",
    "/communityHub",
    "/cycles",
    "/deeplink-handler",
    "/deployment-login",
    "/desktop",
    "/desktopApp/auth",
    "/desktopApp/authSuccess",
    "/desktopApp/home",
    "/desktopApp/open",
    "/dev/confetti",
    "/developer-frameworks",
    "/developerDay",
    "/evaluations",
    "/expiredPrivateRepl",
    "/extensions",
    "/extensions/extension",
    "/externalClaim",
    "/forgot",
    "/glitch",
    "/googlenext",
    "/grab",
    "/help",
    "/home",
    "/hostingDeployments",
    "/hostingDeployments/hostingDeployment",
    "/import",
    "/import/[provider]",
    "/instantGitHubContentsImport",
    "/integrations",
    "/integrations/[connectorName]",
    "/integrations/[connectorName]/apps/[appId]",
    "/language",
    "/mark",
    "/mobile",
    "/mobileApp/home",
    "/mobileApp/startWithAI",
    "/mobileDownload",
    "/mock-home",
    "/native-saml-sign-in",
    "/newExtension",
    "/notifications",
    "/pricing",
    "/profile",
    "/replEmbed",
    "/replEnvironmentDesktop",
    "/replEnvironmentMobile",
    "/replView",
    "/replitAuth",
    "/replitAuthConsent",
    "/replitAuthError",
    "/replsDashboard",
    "/rewind2025",
    "/routeTest",
    "/search",
    "/site/githubClassroomNotice",
    "/stripe-checkout-error",
    "/stripe-checkout-success",
    "/t/join",
    "/t/new",
    "/t/[orgSlug]",
    "/t/[orgSlug]/accept-invite/[inviteCode]",
    "/t/[orgSlug]/accept-sponsored-subscription/[inviteCode]",
    "/t/[orgSlug]/analytics",
    "/t/[orgSlug]/deployments",
    "/t/[orgSlug]/developer-frameworks",
    "/t/[orgSlug]/groups",
    "/t/[orgSlug]/groups/[groupSlug]/[groupId]/members",
    "/t/[orgSlug]/groups/[groupSlug]/[groupId]/permissions",
    "/t/[orgSlug]/groups/[groupSlug]/[groupId]/settings",
    "/t/[orgSlug]/integrations",
    "/t/[orgSlug]/integrations/[connectorName]",
    "/t/[orgSlug]/integrations/[connectorName]/apps/[appId]",
    "/t/[orgSlug]/members",
    "/t/[orgSlug]/profile",
    "/t/[orgSlug]/profile/settings",
    "/t/[orgSlug]/projects",
    "/t/[orgSlug]/projects/[projectId]",
    "/t/[orgSlug]/repls",
    "/t/[orgSlug]/security",
    "/t/[orgSlug]/settings/[[...tab]]",
    "/t/[orgSlug]/theme-editor",
    "/t/[orgSlug]/usage",
    "/teamError",
    "/teams/join",
    "/teams/new",
    "/templates/templates",
    "/templates/templatesCategory",
    "/theme-editor",
    "/themes",
    "/themes/create",
    "/themes/edit",
    "/themes/theme",
    "/unauthorized-deployment",
    "/unauthorized-devdomain",
    "/usage",
    "/userDataExport",
    "/verify",
    "/verifyEmail",
    "/watchNixMigration",
    "/welcome"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()